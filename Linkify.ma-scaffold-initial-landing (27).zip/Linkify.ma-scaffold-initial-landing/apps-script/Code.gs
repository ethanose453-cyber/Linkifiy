/* Linkify.ma - Google Apps Script backend (ASCII-safe, paste-proof) */

/* ===== Fill these 3 values ===== */
const CONFIG = {
  SHEET_ID:        "PASTE_GOOGLE_SHEET_ID_HERE",
  DRIVE_FOLDER_ID: "PASTE_DRIVE_FOLDER_ID_HERE",
  NOTIFY_EMAIL:    "PASTE_YOUR_EMAIL_HERE"
};

/* Column order in the Sheet (rename row 1 in the Sheet to Arabic if you want) */
const COLUMNS = ["submittedAt","first_name","last_name","age","gender","city","city_other",
"neighborhood","whatsapp","email","transport","license","relocate","track","diploma",
"diploma_other","specialty","university","lang_ar","lang_fr","lang_en","lang_es","lang_de",
"subjects","levels","institution_types","schedule","substitute","has_experience","exp_years","last_inst",
"last_role","schools","skills","skill_other_text","consent","CV_URL","CERTS_URL","PHOTO_URL"];

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.tryLock(30000);
  try {
    const data = JSON.parse(e.postData.contents);
    // anti-spam: reject if honeypot field was filled (bots fill it, humans can't see it)
    if (data.website && String(data.website).trim() !== "") {
      return out_({ status: "ignored" });
    }
    const cache = CacheService.getScriptCache();
    const subId = data.submissionId ? String(data.submissionId) : "";
    if (subId && cache.get("sub_" + subId)) {
      return out_({ status: "duplicate" });
    }
    const folder = DriveApp.getFolderById(CONFIG.DRIVE_FOLDER_ID);
    const nm = ((data.first_name || "") + "_" + (data.last_name || "")).trim() || "teacher";
    const files = data.files || {};
    data.CV_URL    = saveFile(folder, files.cv,    "CV_" + nm);
    data.CERTS_URL = saveFile(folder, files.certs, "certs_" + nm);
    data.PHOTO_URL = saveFile(folder, files.photo, "photo_" + nm);
    const sheet = getSheet_();
    sheet.appendRow(COLUMNS.map(function (k) { return data[k] != null ? data[k] : ""; }));
    if (subId) cache.put("sub_" + subId, "1", 21600);
    notify_(data);
    return out_({ status: "success" });
  } catch (err) {
    return out_({ status: "error", message: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet() {
  return out_({ status: "ok", message: "Linkify backend is running" });
}

function saveFile(folder, f, base) {
  if (!f || !f.data) return "";
  const bytes = Utilities.base64Decode(f.data);
  const ext = (f.name && f.name.indexOf(".") > -1) ? "." + f.name.split(".").pop() : "";
  const blob = Utilities.newBlob(bytes, f.type || "application/octet-stream", base + ext);
  return folder.createFile(blob).getUrl();
}

function getSheet_() {
  const sheet = SpreadsheetApp.openById(CONFIG.SHEET_ID).getSheets()[0];
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(COLUMNS);
    sheet.getRange(1, 1, 1, COLUMNS.length).setFontWeight("bold").setBackground("#126cb4").setFontColor("#ffffff");
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function notify_(data) {
  if (!CONFIG.NOTIFY_EMAIL || CONFIG.NOTIFY_EMAIL.indexOf("PASTE") > -1) return;
  const name = ((data.first_name || "") + " " + (data.last_name || "")).trim();
  MailApp.sendEmail(CONFIG.NOTIFY_EMAIL, "New Linkify registration: " + name, "A new teacher registered. Open the Google Sheet for full details.");
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
